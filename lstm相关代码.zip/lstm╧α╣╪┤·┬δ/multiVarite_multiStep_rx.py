import time
import os
import pickle
import pandas as pd
import numpy as np
import tensorflow as tf
from keras.models import Sequential
from keras.layers import Dense, LSTM, Dropout, Reshape, CuDNNLSTM
from keras.callbacks import EarlyStopping
from keras.backend.tensorflow_backend import set_session
from keras.layers import RepeatVector
from keras.layers import TimeDistributed
from sklearn.metrics import mean_absolute_error

# 1. 设置gpu配置
# os.environ["CUDA_VISIBLE_DEVICES"] = '0'
config = tf.ConfigProto()
config.gpu_options.allow_growth = True
gpu_num = os.getpid() % 2
config.gpu_options.visible_device_list = str(gpu_num)
set_session(tf.Session(config=config))

# 2. 生成多维RX数据
data = np.load('opticfull.npy', allow_pickle=True).item()
fourGAll = np.load('fourGAll.npy', allow_pickle=True)
fiberId = list(data.keys())
sample = []
for ip in fourGAll:
	if len(ip) == 4:
		for loc in ip:
			sample.append(data[fiberId[loc]]['rx'])

start_time = time.time()
# data = pd.read_csv('data_gmk_714.csv')
# data = data.iloc[:, :1200]
# print(data.shape)
# with open('gmk_rx.txt', 'rb') as f:
# 	sample = pickle.load(f)
data_sample = pd.DataFrame(sample)
print(data_sample.shape)
data_sample_1200 = data_sample.head(20000)
data_sample_1200_T = data_sample_1200.T
data_values = data_sample_1200_T.values
print(data_values.shape)

# 3.数据预处理， 生成训练集和 测试集
n_steps_in = 168
n_steps_out = 24
length = data_values.shape[0]
X, y = list(), list()

for i in range(length):
	end_ix = i + n_steps_in
	out_end_ix = end_ix + n_steps_out
	if out_end_ix > length:
		break
	seq_x, seq_y = data_values[i:end_ix, :], data_values[end_ix:out_end_ix, :]
	X.append(seq_x)
	y.append(seq_y)
X = np.array(X, dtype=np.float16)
y = np.array(y, dtype=np.float16)
n_features = X.shape[2]

test_num = 2
val_num = 3
X_train = X[:X.shape[0] - test_num, :, :]
print("X_train's shape is ", X_train.shape)
y_train = y[:X.shape[0] - test_num, :, :]
print("y_train's shape is ", y_train.shape)
X_test = X[-test_num:, :, :]
y_test = y[-test_num:, :, :]

# 4. 定义模型

model = Sequential()
model.add(CuDNNLSTM(200, return_sequences=True, input_shape=(n_steps_in, n_features)))
model.add(CuDNNLSTM(200))
model.add(Dense(n_steps_out*n_features))
model.add(Reshape((n_steps_out, n_features)))
model.compile(optimizer='adam', loss='mse')
'''
model = Sequential()
model.add(CuDNNLSTM(200, input_shape=(n_steps_in, n_features)))
model.add(RepeatVector(n_steps_out))
model.add(CuDNNLSTM(200, return_sequences=True))
model.add(TimeDistributed(Dense(n_features)))
model.compile(optimizer='adam', loss='mse')
'''
# 5. 模型训练及效果评估
early_stopping = EarlyStopping(monitor='val_loss', min_delta=0.0001, patience=0, verbose=2)
model.fit(X_train, y_train, epochs=500, batch_size=32, validation_split=0.1, callbacks=[early_stopping])
yhat = model.predict(X_test, verbose=0)
print('the shape of yhat:', yhat.shape)
predict_end_time = time.time()
print('134 Model end up with predicting, the Timestamp is %.2f and local time is %s' % (
	predict_end_time, time.strftime("%Y.%m.%d %H:%M:%S", time.localtime())))

# 6. 模型评估
this_mae = []
this_mape = []
for i in range(test_num):
	real = y_test[i]
	predict = yhat[i]
	for idx in range(yhat.shape[2]):
		mape = np.sum(list(map(lambda x, y: abs((x - y) / x) if x != 0 else abs(x - y) / 1, real[:, idx].tolist(),
		                       predict[:, idx].tolist()))) / len(real[:, idx].tolist())
		mae = mean_absolute_error(real[:, idx], predict[:, idx])
		this_mape.append(mape)
		this_mae.append(mae)
		real_str = ','.join([str(i) for i in real[:, idx].tolist()])
		predict_str = ','.join([str(i) for i in predict[:, idx].tolist()])
		with open('real_predict_0719_1200公用模型.txt', 'a+') as f:
			f.write('real_' + str(idx) + ':[' + real_str + ']\n')
			f.write('predict_' + str(idx)+ ':[' + predict_str + ']\n')
error_mae_str = ','.join([str(ele) for ele in this_mae])
error_mape_str = ','.join([str(ele) for ele in this_mape])
with open('result0719_1200公用模型.txt', 'a+') as f:
	f.write('error_mae' + '_str: [' + error_mae_str + ']\n')
	f.write('error_mape' + '_str: [' + error_mape_str + ']\n')
# print('error_mae' + '_str: [' + error_mae_str + ']\n')
# print('error_mape' + '_str: [' + error_mape_str + ']\n')
mean_mae = np.mean(this_mae)
mean_mape = np.mean(this_mape)
print('mean_mae is ', mean_mae)
print('mean_mape is ', mean_mape)
end_time = time.time()
print('Elapsed time is {}'.format(end_time-start_time))