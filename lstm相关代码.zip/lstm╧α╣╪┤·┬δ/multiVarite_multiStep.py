import random
import pickle
import time
import os
import random
import pandas as pd
import numpy as np
from numpy import hstack
import multiprocessing
from multiprocessing import Pool
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.preprocessing import MinMaxScaler

valid_set_size_percentage = 10
test_set_size_percentage = 10
# os.environ["CUDA_VISIBLE_DEVICES"] = '0'

def get_data_from_npy():
	print("开始从npy获取数据")
	data = np.load('opticfull.npy', allow_pickle=True).item()
	# 53759的字典，每个字典是含有rx、tx、ts和bias键的字典，值为长度不定（621, 24, 714）的列表
	fourGAll = np.load('fourGAll.npy', allow_pickle=True)
	# 长度为16523的ndarray object, 每一个元素为长度2-4的列表
	fiberId = list(data.keys())  # 字典的键组成的列表
	data_lst = []
	for ele in fiberId:
		tmp_lst = [data[ele]['rx'], data[ele]['tx'], data[ele]['bias']]
		data_lst.append(tmp_lst)
	print("从npy获取数据成功")
	return data, fourGAll, fiberId


def train(data_lst, index):
	import tensorflow as tf
	import keras
	from keras.models import Sequential
	from keras.layers import Dense, LSTM, Dropout, Reshape, CuDNNLSTM
	from keras.callbacks import EarlyStopping
	from keras.layers import RepeatVector
	from keras.layers import TimeDistributed
	
	# ------------------------------
	# this block enables GPU enabled multiprocessing
	core_config = tf.ConfigProto()
	core_config.gpu_options.allow_growth = True
	gpu_num = os.getpid() % 2
	core_config.gpu_options.visible_device_list = str(gpu_num)
	session = tf.Session(config=core_config)
	keras.backend.set_session(session)
	
	# ------------------------------
	def split_sequence(sequence, n_steps_in, n_steps_out):
		X, y = list(), list()
		in_seq1 = np.array(sequence['rx'])
		in_seq2 = np.array(sequence['tx'])
		in_seq3 = np.array(sequence['bias'])
		assert len(in_seq1) == len(in_seq2) and len(in_seq2) == len(in_seq3)
		length = len(in_seq1)
		# convert to [rows, columns] structure
		in_seq1 = in_seq1.reshape((len(in_seq1), 1))
		in_seq2 = in_seq2.reshape((len(in_seq2), 1))
		in_seq3 = in_seq3.reshape((len(in_seq3), 1))
		# horizontally stack columns
		dataset = hstack((in_seq1, in_seq2, in_seq3))
		print('the shape of dataset is ', dataset.shape)
		for i in range(length):
			# find the end of this pattern
			end_ix = i + n_steps_in
			out_end_ix = end_ix + n_steps_out
			# check if we are beyond the sequence
			if out_end_ix > length:
				break
			# gather input and output parts of the pattern
			seq_x, seq_y = dataset[i:end_ix, :], dataset[end_ix:out_end_ix, :]
			# print('the shape of seq_x is ', seq_x.shape)
			# print('the shape of seq_y is ', seq_y.shape)
			X.append(seq_x)
			y.append(seq_y)
		return np.array(X, dtype=np.float16), np.array(y, dtype=np.float16)
	
	raw_seq = data_lst[index]
	# scaler = MinMaxScaler(feature_range=(0, 1))
	# raw_seq = scaler.fit_transform(raw_seq)
	n_steps_in = 168
	n_steps_out = 24
	if len(raw_seq['rx']) <= (n_steps_out + n_steps_in):
		session.close()
		keras.backend.clear_session()
		return [], []
	# covert into input/output
	X, y = split_sequence(raw_seq, n_steps_in, n_steps_out)
	print(X.shape, y.shape)
	n_features = X.shape[2]
	# X = X.reshape((X.shape[0], X.shape[1], n_features))
	
	test_num = 2
	val_num = 3
	X_train = X[:X.shape[0] - test_num - val_num, :, :]
	print("X_train's shape is ", X_train.shape)
	y_train = y[:X.shape[0] - test_num - val_num, :, :]
	print("y_train's shape is ", y_train.shape)
	# X_val = X[-(val_num + test_num):(-test_num), :, :]
	# y_val = y[-(val_num + test_num):(-test_num), :]
	X_test = X[-test_num:, :, :]
	y_test = y[-test_num:, :, :]
	
	# define model
	model = Sequential()
	# model.add(LSTM(200, activation='relu', input_shape=(n_steps_in, n_features)))
	model.add(CuDNNLSTM(200, input_shape=(n_steps_in, n_features)))
	model.add(RepeatVector(n_steps_out))
	model.add(CuDNNLSTM(200, return_sequences=True))
	model.add(TimeDistributed(Dense(n_features)))
	model.compile(optimizer='adam', loss='mse')
	"""
	# define model
	model = Sequential()
	model.add(CuDNNLSTM(200, return_sequences=True, input_shape=(n_steps_in, n_features)))
	model.add(CuDNNLSTM(200))
	model.add(Dense(n_steps_out*n_features))
	model.add(Reshape((n_steps_out, n_features)))
	model.compile(optimizer='adam', loss='mse')
	"""
	# fit model
	fit_start_time = time.time()
	print('126 Model starts with fitting, the Timestamp is %.2f and local time is %s' % (
		fit_start_time, time.strftime("%Y.%m.%d %H:%M:%S", time.localtime())))
	early_stopping = EarlyStopping(monitor='val_loss', min_delta=0.0001, patience=0, verbose=2)
	model.fit(X_train, y_train, epochs=500, batch_size=32, validation_split=0.1, callbacks=[early_stopping])
	# model.save("model_for_%s.hdf5" % index)
	fit_end_time = time.time()
	print('131 Model ends up fitting amd starts with predicting, the Timestamp is %.2f and local time is %s' % (
		fit_end_time, time.strftime("%Y.%m.%d %H:%M:%S", time.localtime())))
	yhat = model.predict(X_test, verbose=0)
	print('the shape of yhat:\n', yhat.shape)
	predict_end_time = time.time()
	print('134 Model end up with predicting, the Timestamp is %.2f and local time is %s' % (
		predict_end_time, time.strftime("%Y.%m.%d %H:%M:%S", time.localtime())))
	this_mae = []
	this_mape = []
	
	for i in range(test_num):
		real = y_test[i]
		predict = yhat[i]
		for idx in range(yhat.shape[2]):
			mape = np.sum(list(map(lambda x, y: abs((x - y) / x) if x != 0 else abs(x - y) / 1, real[:, idx].tolist(),
			                       predict[:, idx].tolist()))) / len(real[:, idx].tolist())
			mae = mean_absolute_error(real[:, idx], predict[:, idx])
			this_mape.append(mape)
			this_mae.append(mae)
			real_str = ','.join([str(i) for i in real[:, idx].tolist()])
			predict_str = ','.join([str(i) for i in predict[:, idx].tolist()])
			with open('real_predict_0718.txt', 'a+') as f:
				f.write('real_' + str(idx) + '_' + str(index) + ':[' + real_str + ']\n')
				f.write('predict_' + str(idx) + '_' + str(index) + ':[' + predict_str + ']\n')
	error_mae_str = ','.join([str(ele) for ele in this_mae])
	error_mape_str = ','.join([str(ele) for ele in this_mape])
	with open('mae_results_0718.txt', 'a+') as f:
		f.write('error_mae' + str(index) + '_str: [' + error_mae_str + ']\n')
		f.write('error_mape' + str(index) + '_str: [' + error_mape_str + ']\n')
	# ------------------------------
	# finally, close sessions
	session.close()
	keras.backend.clear_session()
	return this_mae, this_mape


if __name__ == '__main__':
	total_time_start = time.time()
	multiprocessing.set_start_method('spawn', force=True)
	data, fourGAll, fiberId = get_data_from_npy()
	# first_1200 = np.random.permutation(53759)
	# choice_sample = random.sample(lst, 1200)
	with open('gmk_ip.txt', 'rb') as f:
		gmk_ip = pickle.load(f)
	my_tuple = [(data, fiberId[gmk_ip[i]]) for i in range(0, 1200)]
	start_time = time.time()
	with Pool(10) as pool:
		res = pool.starmap(train, my_tuple)
	
	print('the length of return from train is ', len(res))
	end_time = time.time()
	print('the Total_Elapsed time of using GPU:', end_time - start_time)
	
	errors_mae = []
	errors_mape = []
	for i in range(len(res)):
		errors_mae.append(res[i][0])
		errors_mape.append(res[i][1])
	error_mae = [ele for lst in errors_mae for ele in lst]
	error_mae_mean = np.mean(error_mae)
	error_mape = [ele for lst in errors_mape for ele in lst]
	error_mape_mean = np.mean(error_mape)
	print('the length of error_mae is {}, and the mean of mae is {}'.format(len(error_mae), error_mae_mean))
	print('the length of error_mape is {}, and the mean of mape is {}'.format(len(error_mape), error_mape_mean))
	total_time_end = time.time()
	print('Total_Elapsed time is:', total_time_end - total_time_start)
