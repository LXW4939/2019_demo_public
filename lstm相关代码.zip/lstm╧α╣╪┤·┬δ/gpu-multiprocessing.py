import random
import time
import os
import pickle
import random
import pandas as pd
import numpy as np
import multiprocessing
from multiprocessing import Pool
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.preprocessing import MinMaxScaler

valid_set_size_percentage = 10
test_set_size_percentage = 10
# os.environ["CUDA_VISIBLE_DEVICES"] = ''

def get_data_from_npy():
	print("开始从npy获取数据")
	data = np.load('opticfull.npy', allow_pickle=True).item()
	# 53759的字典，每个字典是含有rx、tx、ts和bias键的字典，值为长度不定（621, 24, 714）的列表
	fourGAll = np.load('fourGAll.npy', allow_pickle=True)
	# 长度为16523的ndarray object, 每一个元素为长度2-4的列表
	fiberId = list(data.keys())  # 字典的键组成的列表
	data_lst = []
	for ele in fiberId:
		tmp_lst = data[ele]['rx']
		data_lst.append(tmp_lst)
	# for i in data.keys():
	# 	fiberId.append(i)
	print("从npy获取数据成功")
	return data, fourGAll, fiberId


# 制作训练集、测试集和验证集
def load_data(data_lst, index, seq_len):
	data_raw = data_lst[index]
	data = []
	
	# create all possible sequences of length seq_len
	for index in range(len(data_raw) - seq_len):
		data.append(data_raw[index: index + seq_len])
	
	data = np.array(data)
	print('data.shape:', data.shape)
	valid_set_size = int(np.round(valid_set_size_percentage / 100 * data.shape[0]))
	test_set_size = int(np.round(test_set_size_percentage / 100 * data.shape[0]))
	train_set_size = data.shape[0] - (valid_set_size + test_set_size)
	
	x_train = data[:train_set_size, :-1, :]
	y_train = data[:train_set_size, -1, :]
	
	x_valid = data[train_set_size:train_set_size + valid_set_size, :-1, :]
	y_valid = data[train_set_size:train_set_size + valid_set_size, -1, :]
	
	x_test = data[train_set_size + valid_set_size:, :-1, :]
	y_test = data[train_set_size + valid_set_size:, -1, :]
	
	return [x_train, y_train, x_valid, y_valid, x_test, y_test]


def train(data_lst, index):
	import tensorflow as tf
	import keras
	from keras.models import Sequential
	from keras.layers import Dense, LSTM, Dropout, CuDNNLSTM
	from keras.callbacks import EarlyStopping
	
	# ------------------------------
	# this block enables GPU enabled multiprocessing
	core_config = tf.ConfigProto()
	core_config.gpu_options.allow_growth = True
	gpu_num = os.getpid() % 2
	core_config.gpu_options.visible_device_list = str(gpu_num)
	session = tf.Session(config=core_config)
	keras.backend.set_session(session)
	
	# ------------------------------
	# split a univariate sequence into samples
	def split_sequence(sequence, n_steps_in, n_steps_out):
		X, y = list(), list()
		for i in range(len(sequence)):
			# find the end of this pattern
			end_ix = i + n_steps_in
			out_end_ix = end_ix + n_steps_out
			# check if we are beyond the sequence
			if out_end_ix > len(sequence):
				break
			# gather input and output parts of the pattern
			seq_x, seq_y = sequence[i:end_ix], sequence[end_ix:out_end_ix]
			X.append(seq_x)
			y.append(seq_y)
		return np.array(X, dtype=np.float16), np.array(y, dtype=np.float16)
	
	raw_seq = data_lst[index] #['rx']
	# scaler = MinMaxScaler(feature_range=(0, 1))
	# raw_seq = scaler.fit_transform(raw_seq)
	n_steps_in = 168
	n_steps_out = 24
	if len(raw_seq) <= (n_steps_out + n_steps_in):
		session.close()
		keras.backend.clear_session()
		return [], []
	X, y = split_sequence(raw_seq, n_steps_in, n_steps_out)
	# X = tf.convert_to_tensor(X, dtype=tf.float16)
	# y = tf.convert_to_tensor(y, dtype=tf.float16)
	# reshape from [samples, timesteps] into [samples, timesteps, features]
	n_features = 1
	# X = tf.reshape(X, [X.shape[0], X.shape[1], n_features])
	X = X.reshape((X.shape[0], X.shape[1], n_features))
	
	test_num = 2
	val_num = 3
	X_train = X[:X.shape[0]-test_num-val_num, :, :]
	print("X_train's shape is ", X_train.shape)
	y_train = y[:X.shape[0]-test_num-val_num, :]
	X_val = X[-(val_num+test_num):(-test_num), :, :]
	y_val = y[-(val_num+test_num):(-test_num), :]
	X_test = X[-test_num:, :, :]
	y_test = y[-test_num:, :]
	
	# define model
	model = Sequential()
	model.add(CuDNNLSTM(200, return_sequences=True, input_shape=(n_steps_in, n_features)))
	model.add(CuDNNLSTM(200))
	# model.add(LSTM(100, return_sequences=True, activation='sigmoid', input_shape=(n_steps_in, n_features)))
	# model.add(LSTM(100, activation='sigmoid'))
	model.add(Dense(n_steps_out))
	model.compile(optimizer='adam', loss='mse')
	# fit model
	fit_start_time = time.time() # time.strftime("%b %d %Y %H:%M:%S", time.localtime())
	print('126 Model starts with fitting, the Timestamp is %.2f and local time is %s' % (fit_start_time, time.strftime("%Y.%m.%d %H:%M:%S", time.localtime())))
	early_stopping = EarlyStopping(monitor='val_loss', min_delta=0.0001, patience=0, verbose=2)
	model.fit(X_train, y_train, epochs=500, batch_size=32, validation_split=0.1, callbacks=[early_stopping]) # validation_data=(X_val, y_val)
	# model.save("model_for_%s.hdf5" % index)
	fit_end_time = time.time()
	print('131 Model ends up fitting amd starts with predicting, the Timestamp is %.2f and local time is %s' % (fit_end_time, time.strftime("%Y.%m.%d %H:%M:%S", time.localtime())))
	yhat = model.predict(X_test, verbose=0)
	predict_end_time = time.time()
	print('134 Model end up with predicting, the Timestamp is %.2f and local time is %s' % (predict_end_time, time.strftime("%Y.%m.%d %H:%M:%S", time.localtime())))
	error_mae = []
	error_mape = []
	for i in range(test_num):
		real = y_test[i]
		predict = yhat[i]
		mae = mean_absolute_error(real, predict)
		mape = np.sum(list(map(lambda x, y: abs((x - y) / x) if x != 0 else abs(x - y) / 1, real, predict))) / len(real)
		error_mape.append(mape)
		error_mae.append(mae)
		real_str = ','.join([str(i) for i in real])
		predict_str = ','.join([str(i) for i in predict])
		with open('real_predict_0720_1200个模型.txt', 'a+') as f:
			f.write('real_'+str(index)+':['+real_str + ']\n')
			f.write('predict_' + str(index) + ':[' + predict_str + ']\n')
	error_mae_str = ','.join([str(ele) for ele in error_mae])
	error_mape_str = ','.join([str(ele) for ele in error_mape])
	with open('mae_results_0720_1200个模型.txt', 'a+') as f:
		f.write('error_mae'+str(index)+'_str: [' + error_mae_str + ']\n')
		f.write('error_mape' + str(index) + '_str: [' + error_mape_str + ']\n')
	"""
	prepare input and output values
	df = df.drop(columns=['index'])

	data = df.drop(columns=['target']).values
	target = df['target']
	#------------------------------
	model = Sequential()
	model.add(Dense(5 #num of hidden units
	, input_shape=(data.shape[1],))) #num of features in input layer
	model.add(Activation('sigmoid'))

	model.add(Dense(1))#number of nodes in output layer
	model.add(Activation('sigmoid'))

	model.compile(loss='mse', optimizer=keras.optimizers.Adam())
	#------------------------------
	model.fit(data, target, epochs = 5000, verbose = 1)
	model.save("model_for_%s.hdf5" % index)
	"""
	# ------------------------------
	# finally, close sessions
	session.close()
	keras.backend.clear_session()
	return error_mae, error_mape


if __name__ == '__main__':
	multiprocessing.set_start_method('spawn', force=True)
	data, fourGAll, fiberId = get_data_from_npy()
	# first_1200 = np.random.permutation(53759)
	# choice_sample = random.sample(lst, 1200)
	with open('gmk_rx.txt', 'rb') as fr:
		sample = pickle.load(fr)
	my_tuple = [(sample, i) for i in [4, 1241, 2474, 3729]]
	
	start_time = time.time()
	with Pool(10) as pool:
		res = pool.starmap(train, my_tuple)
	print('the length of return from train is ', len(res))
	end_time = time.time()
	print('Total_Elapsed time:', end_time - start_time)
	
	error_mae = []
	error_mape = []
	for i in range(len(res)):
		error_mae.append(res[i][0])
		error_mape.append(res[i][1])
	# error_mae = np.array(error_mae, dtype=np.float16)
	# error_mae_mean = np.mean(error_mae)
	error_mae = [ele for lst in error_mae for ele in lst]
	error_mae_mean = np.mean(error_mae)
	# error_mape = np.array(error_mape, dtype=np.float16)
	# error_mape_mean = np.mean(error_mape)
	error_mape = [ele for lst in error_mape for ele in lst]
	error_mape_mean = np.mean(error_mape)
	print('the length of error_mae is {}, and the mean of mae is {}'.format(len(error_mae), error_mae_mean))
	print('the length of error_mape is {}, and the mean of mape is {}'.format(len(error_mape), error_mape_mean))
	

